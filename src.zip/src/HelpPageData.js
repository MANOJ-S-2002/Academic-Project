const questions = [
  {
    id: 1,
    question: "What Should I do initially? ",
    Answer: "You need to login first with the your email",
  },

  {
    id: 2,
    question:
      "Do I need to verify my mobile number or email address every time I log in?",
    Answer:
      " As the verification step is a one time process, you won't have to do it again once your account is verified",
  },
  {
    id: 3,
    question:
      "Do I receive the report whenever i need?",
    Answer:
"No, the report will be generated for every half an hour of the child's mobile usage"  },
  {
    id: 4,
    question:
      "If I have found a security Bug/Vulnerability/Issue what should I do?",
    Answer:
      "We take security very seriously at SPAM. If you have found an issue on SPAM, you can report it to security@spam.com with the below details:1. Steps to reproduce the bug/issue 2. Your web browser/mobile browser's name and version3. Screenshot/screencast (if any).",
  },
];
export default questions;
